#ifndef GG_Maze_h
#define GG_Maze_h

#if ARDUINO >= 100
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

#ifndef Max_US_Range
#define Max_US_Range 24000;  // 23200 µs = 400cm
#endif

#define CM 1
#define INC 0
#define MaxStraightForwardCorrection 127
#define MinStraightForwardCorrection -127
#define DefaultSpeed 127

class Ultrasonic
{
  public:
    Ultrasonic(int Trig, int Echo);
	Ultrasonic(int Trig, int Echo, long TimeOut);
    long Timing();
    long Measure(int unit);
//	void SetUnit(int Unit);

  private:
    int Trig_pin,Echo_pin;
	int Measure_Unit=CM;
	long Time_out,duration;
};

class DC_Motor
{
  public:
    DC_Motor(int Left_Forward,int Left_Backward,int Right_Forward,int Right_Backward);
	void Mortor(bool Left_Forward,bool Left_Backward,bool Right_Forward,bool Right_Backward);
    void MortorPWM(int Left_Forward,int Left_Backward,int Right_Forward,int Right_Backward);
	void SetSpeed(int speed);
    void Forward(); 
	void Backward();
	void TurnLeft(int TurnType);
	void TurnRight(int TurnType);
    void ForwardS(); 
	void BackwardS();
	void TurnLeftS(int sDifference);
	void TurnRightS(int sDifference);
	void Stop();
	void Wait();
	void StopS();
	void WaitS();
	void SetStraightAdj(int adj);

  private:
	void MortorS9110S(int Left_Forward,bool Left_Backward,int Right_Forward,bool Right_Backward);
	void MortorS(bool lForward,bool lBackward,bool rForward,bool rBackward);
	int LF_Pin,LB_Pin,RF_Pin,RB_Pin;
	int rate=DefaultSpeed;
	int dc_SFC=0; //車子直進校正
};

class Trace
{
  public:
	Trace(int IrPin);
	bool isDetectBlack();

  private:
    int ir_pin;
};

#endif