// Ultrasonic - Library for HR-SC04 Ultrasonic Ranging Module.
// GitHub: https://github.com/JRodrigoTech/Ultrasonic-HC-SR04
// #### LICENSE ####
// This code is licensed under Creative Commons Share alike
// and Attribution by J.Rodrigo ( http://www.jrodrigo.net ).

#include "GG_Maze.h"

Ultrasonic::Ultrasonic(int Trig, int Echo)
{
   pinMode(Trig,OUTPUT);
   pinMode(Echo,INPUT);
   Trig_pin=Trig;
   Echo_pin=Echo;
//   Time_out=3000;  // 3000 µs = 50cm // 30000 µs = 5 m
   Time_out=Max_US_Range;
}

Ultrasonic::Ultrasonic(int Trig, int Echo, long TimeOut)
{
   pinMode(Trig,OUTPUT);
   pinMode(Echo,INPUT);
   Trig_pin=Trig;
   Echo_pin=Echo;
//   Time_out=3000;  // 3000 µs = 50cm // 30000 µs = 5 m
   Time_out=TimeOut;
}

long Ultrasonic::Timing()
{
  digitalWrite(Trig_pin, LOW);
  delayMicroseconds(2);
  digitalWrite(Trig_pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(Trig_pin, LOW);
  duration = pulseIn(Echo_pin,HIGH,Time_out);
  if ( duration == 0 ) {
	duration = Time_out; }
  return duration;
}

long Ultrasonic::Measure(int Unit)
{
  Timing();
  if ( duration == Time_out ) {
	return 0;
  } else if (Unit) {
//	distance_cm = duration /29 / 2 ;
//	return distance_cm;
    return duration /29 / 2 ;
  } else {
//	distance_inc = duration /74 / 2;
//	return distance_inc; }
    return duration /74 / 2 ;
  }
}

DC_Motor::DC_Motor(int Left_Forward,int Left_Backward,int Right_Forward,int Right_Backward) {
   pinMode(Left_Forward,OUTPUT);
   pinMode(Left_Backward,OUTPUT);
   pinMode(Right_Forward,OUTPUT);
   pinMode(Right_Backward,OUTPUT);
   LF_Pin=Left_Forward;
   LB_Pin=Left_Backward;
   RF_Pin=Right_Forward;
   RB_Pin=Right_Backward;
   dc_SFC=0;
   rate=DefaultSpeed;
}

void DC_Motor::Mortor(bool Left_Forward,bool Left_Backward,bool Right_Forward,bool Right_Backward) {
  digitalWrite(LF_Pin,Left_Forward);
  digitalWrite(LB_Pin,Left_Backward);
  digitalWrite(RF_Pin,Right_Forward);
  digitalWrite(RB_Pin,Right_Backward);
}

void DC_Motor::MortorS(bool lForward,bool lBackward,bool rForward,bool rBackward) {
  analogWrite(LF_Pin,lForward*(rate+dc_SFC));
  analogWrite(LB_Pin,lBackward*(rate+dc_SFC));
  analogWrite(RF_Pin,rForward*(rate+dc_SFC));
  analogWrite(RB_Pin,rBackward*(rate+dc_SFC));
}

void DC_Motor::MortorS9110S(int Left_Forward,bool Left_Backward,int Right_Forward,bool Right_Backward) {
  analogWrite(LF_Pin,Left_Forward);
  digitalWrite(LB_Pin,Left_Backward);
  analogWrite(RF_Pin,Right_Forward);
  digitalWrite(RB_Pin,Right_Backward);
}

void DC_Motor::MortorPWM(int Left_Forward,int Left_Backward,int Right_Forward,int Right_Backward) {
  analogWrite(LF_Pin,Left_Forward);
  analogWrite(LB_Pin,Left_Backward);
  analogWrite(RF_Pin,Right_Forward);
  analogWrite(RB_Pin,Right_Backward);
}

void DC_Motor::SetSpeed(int speed) {
  int min,max;
  if (speed<0) return;
  if (dc_SFC>=0) {
	max=speed+dc_SFC;
	min=speed-dc_SFC;
  } else {
	max=speed-dc_SFC;
	min=speed+dc_SFC;
  }
  if ((max<255) && (min>0)) { rate=speed; }
}

void DC_Motor::SetStraightAdj(int adj) {
  if ((adj<MaxStraightForwardCorrection) && (adj>MinStraightForwardCorrection)) {
	dc_SFC=adj;
	rate=DefaultSpeed;
  }
}

void DC_Motor::Forward() {
  Mortor(HIGH,LOW,HIGH,LOW);
}

void DC_Motor::Backward() {
  Mortor(LOW,HIGH,LOW,HIGH);
}

void DC_Motor::TurnLeft(int TurnType) {
    if (TurnType==0) {  //小角度
      Mortor(LOW,LOW,HIGH,LOW);
    } else if (TurnType<0) {  //原地
      Mortor(LOW,HIGH,HIGH,LOW);
	}
}

void DC_Motor::TurnRight(int TurnType) {
    if (TurnType==0) {  //小角度
      Mortor(HIGH,LOW,LOW,LOW);
    } else if (TurnType<0) {  //原地
      Mortor(HIGH,LOW,LOW,HIGH);
	}
}

void DC_Motor::ForwardS() {
  MortorS(HIGH,LOW,HIGH,LOW);
}

void DC_Motor::BackwardS() {
  MortorS(LOW,HIGH,LOW,HIGH);
}

void DC_Motor::TurnLeftS(int sDifference) {
    if (sDifference==0) {  //小角度
      MortorPWM(0,0,rate,0);
    } else if (sDifference<0) {  //原地
      MortorPWM(0,rate,rate,0);
    } else {  //圓弧
	  if (sDifference>rate) sDifference=rate;
      MortorPWM(rate-sDifference,0,rate,0);
    }
}

void DC_Motor::TurnRightS(int sDifference) {
    if (sDifference==0) {  //小角度
      MortorS(HIGH,LOW,LOW,LOW);
    } else if (sDifference<0) {  //原地
      MortorS(HIGH,LOW,LOW,HIGH);
    } else {  //圓弧
	  if (sDifference>rate) sDifference=rate;
      MortorPWM(rate,0,rate-sDifference,0);
    }
}

void DC_Motor::Stop() {
  Mortor(LOW,LOW,LOW,LOW);
}

void DC_Motor::Wait() {
  Mortor(HIGH,HIGH,HIGH,HIGH);
}

void DC_Motor::StopS() {
  MortorPWM(0,0,0,0);
}

void DC_Motor::WaitS() {
  MortorPWM(255,255,255,255);
}

Trace::Trace(int IrPin) {
  ir_pin=IrPin;
  pinMode(ir_pin,INPUT);
}

bool Trace::isDetectBlack() {
  return digitalRead(ir_pin);
}